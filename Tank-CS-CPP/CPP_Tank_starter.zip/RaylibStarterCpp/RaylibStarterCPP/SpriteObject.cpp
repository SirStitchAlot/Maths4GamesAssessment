#include "SpriteObject.h"


SpriteObject::SpriteObject(){
}

SpriteObject::~SpriteObject(){
}


void SpriteObject::Draw(){
}

void SpriteObject::Load(string filename){
}
